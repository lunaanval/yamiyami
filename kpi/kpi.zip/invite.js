import { db } from "./database.js";

export async function inviteCommand(message) {
  try {
    const result = await db.query(`
      SELECT inviteCode, MAX(inviterName) AS inviterName, MAX(inviterId) AS inviterId, COUNT(*) AS count
      FROM users
      WHERE inviteCode IS NOT NULL
      GROUP BY inviteCode
      ORDER BY count DESC
      LIMIT 50
    `);
    if (result.rows.length === 0) return message.reply("💜 招待データがありません。");

    let text = "💜 **招待コード別 流入人数**\n\n";
    let rank = 1;
    for (const row of result.rows) {
      if (rank > 10) break;
      const member = row.inviterid ? message.guild.members.cache.get(row.inviterid) : null;
      if (!member) continue; // サーバーにいない場合はスキップ
      const code    = row.invitecode ?? "不明";
      const inviter = member.displayName ?? member.user?.globalName ?? "不明";
      text += `${rank++}. **${inviter}** (\`${code}\`)　→ **${row.count}人**\n`;
    }
    if (rank === 1) return message.reply("💜 表示できる招待データがありません。");
    return message.reply(text);
  } catch (err) {
    console.error("!invite エラー:", err);
    return message.reply("エラーが発生しました💜");
  }
}

export async function inviteRetentionCommand(message) {
  try {
    const result = await db.query(`
      SELECT
        inviteCode,
        MAX(inviterId) AS inviterId,
        MAX(inviterName) AS inviterName,
        COUNT(*) AS total,
        SUM(CASE WHEN first7_count >= 3 THEN 1 ELSE 0 END) AS retained
      FROM (
        SELECT u.userId, u.inviteCode, u.inviterId, u.inviterName, COUNT(m.id) AS first7_count
        FROM users u
        LEFT JOIN message_logs m
          ON u.userId = m.userId
         AND m.timestamp BETWEEN u.joinDate AND u.joinDate + INTERVAL '7 days'
        GROUP BY u.userId, u.inviteCode, u.inviterId, u.inviterName
      ) sub
      WHERE inviteCode IS NOT NULL
      GROUP BY inviteCode
      ORDER BY total DESC
      LIMIT 50
    `);
    if (result.rows.length === 0) return message.reply("💜 招待データがありません。");

    let text = "💜 **招待コード別 7日定着率レポート**\n\n";
    let displayed = 0;
    for (const row of result.rows) {
      if (displayed >= 10) break;
      const member = row.inviterid ? message.guild.members.cache.get(row.inviterid) : null;
      if (!member) continue; // サーバーにいない場合はスキップ
      const code     = row.invitecode;
      const inviter  = member.displayName ?? "不明";
      const retained = Number(row.retained) || 0;
      const total    = Number(row.total)    || 0;
      const rate     = total === 0 ? "0.0" : ((retained / total) * 100).toFixed(1);
      const emoji    = rate >= 70 ? "🟢" : rate >= 40 ? "🟡" : "🔴";
      text += `${emoji} \`${code}\`　招待者: **${inviter}**\n　流入: ${total}人　定着: ${retained}人　定着率: **${rate}%**\n\n`;
      displayed++;
    }
    if (displayed === 0) return message.reply("💜 表示できる招待データがありません。");
    return message.reply(text);
  } catch (err) {
    console.error("!inviteRetention エラー:", err);
    return message.reply("エラーが発生しました💜");
  }
}