import { helpCommand } from "./help.js";
import { rankingCommand } from "./ranking.js";
import { retentionCommand } from "./retention.js";
import { exportCommand } from "./export.js";
import { inviteCommand, inviteRetentionCommand } from "./invite.js"; // ← 修正

export async function handleCommands(message){

  const cmd = message.content

  if(cmd === "!help")              return helpCommand(message)
  if(cmd === "!ranking")           return rankingCommand(message)
  if(cmd === "!retention")         return retentionCommand(message)
  if(cmd === "!export")            return exportCommand(message)
  if(cmd === "!invite")            return inviteCommand(message)
  if(cmd === "!inviteRetention")   return inviteRetentionCommand(message) // ← 追加
}