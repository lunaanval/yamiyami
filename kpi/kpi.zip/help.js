export function helpCommand(message){

  message.reply(`
💜 KPI BOT COMMANDS

!7day               直近7日の発言ランキング
!first7             参加後7日以内の発言数ランキング
!retention          7日定着率

!invite             招待コード別 流入人数
!inviteRetention    招待コード別 7日定着率

!ranking monthly    発言ランキングTOP20（月間）画像
!ranking total      発言ランキングTOP20（累計）画像

!export             全KPIをGoogleスプレッドシートに出力
  `)

}