export async function retentionCommand(message){

message.reply("📊 retention calculation module")

}
