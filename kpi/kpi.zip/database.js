import pg from "pg";

const { Pool } = pg;

export const db = new Pool({
  host:     process.env.DB_HOST,
  database: process.env.DB_NAME,
  user:     process.env.DB_USER,
  password: process.env.DB_PASS,
  port:     process.env.DB_PORT
});

export async function initDB(){

  await db.query(`CREATE TABLE IF NOT EXISTS message_logs(
    id SERIAL PRIMARY KEY,
    userid TEXT,
    username TEXT,
    content TEXT,
    timestamp TIMESTAMP
  )`);

  await db.query(`CREATE TABLE IF NOT EXISTS voice_logs(
    id SERIAL PRIMARY KEY,
    userid TEXT,
    jointime TIMESTAMP,
    leavetime TIMESTAMP,
    duration INT
  )`);

  // ↓ 追加
  await db.query(`CREATE TABLE IF NOT EXISTS users(
    userId      TEXT PRIMARY KEY,
    username    TEXT,
    joinDate    TIMESTAMP,
    inviteCode  TEXT,
    inviterId   TEXT,
    inviterName TEXT
  )`);

}