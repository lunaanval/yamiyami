import { db } from "./database.js";

export async function handleMessage(message){

await db.query(`   INSERT INTO message_logs(userid,username,content,timestamp)
  VALUES($1,$2,$3,$4)
  `,
[
message.author.id,
message.author.tag,
message.content,
new Date()
])

}
