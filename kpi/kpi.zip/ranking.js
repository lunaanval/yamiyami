import { db } from "./database.js";

export async function rankingCommand(message){

const result=await db.query(`SELECT username,COUNT(*) as count
FROM message_logs
GROUP BY username
ORDER BY count DESC
LIMIT 10`)

let text="🏆 発言ランキング\n\n"

result.rows.forEach((r,i)=>{
text+=`${i+1}. ${r.username} ${r.count}\n`
})

message.reply(text)

}
