import "dotenv/config"

import { Client, GatewayIntentBits } from "discord.js"

import { initDB } from "./database.js"
import { startDashboard } from "./dashboard.js"

import { handleMessage } from "./messageLogger.js"
import { handleVoice } from "./voiceLogger.js"

import { handleCommands } from "./commands.js"



/* ===========================
   Discord Client
=========================== */

const client = new Client({

  intents: [

    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,

    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,

    GatewayIntentBits.GuildVoiceStates

  ]

})



/* ===========================
   BOT起動
=========================== */

client.once("ready", async () => {

  console.log(`💜 BOT起動: ${client.user.tag}`)

  await initDB()

  startDashboard(client)

})



/* ===========================
   メッセージログ
=========================== */

client.on("messageCreate", async (message) => {

  if (message.author.bot) return

  await handleMessage(message)

  await handleCommands(message)

})



/* ===========================
   VCログ
=========================== */

client.on("voiceStateUpdate", async (oldState, newState) => {

  await handleVoice(oldState, newState)

})



/* ===========================
   ログイン
=========================== */

client.login(process.env.DISCORD_TOKEN)